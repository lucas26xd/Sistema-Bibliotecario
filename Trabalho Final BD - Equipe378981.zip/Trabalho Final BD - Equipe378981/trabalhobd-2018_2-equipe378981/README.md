# TrabalhoBD-2018_2-Equipe378981

Trabalho Final – BD 2018.2 – Equipe 378981

# Membros:
- Ângela Ferreira Magalhães - 378981
- Lucas Costa Santos - 381076

# Requisitos:
 - Java
 - MySQL 5.6, 5.7 (ou superior)

# Passos iniciais
 - Instale todos os requisitos antes de começar
 - Baixe a pasta "Executável" onde se encontram os arquivos 'script.sql' e 'Sistema.jar'
 - Execute o arquivo 'script.sql' no seu SGBD para criar toda a estrutura do banco de dados utilizado na aplicação
 - E pronto, no mais basta executar o arquivo 'Sistema.jar', clicando duas vezes sobre o mesmo, e aproveitar o sistema.
